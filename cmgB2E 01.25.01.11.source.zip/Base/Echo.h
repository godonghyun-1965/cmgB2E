#include "../version.h"

//���̾Ʒα� ���ҽ�
#define rcICO_START 100

#define rcDLG_START 200
#define rcTXT_LABEL 201
#define rcEDT_PASSW 202
#define rcEDT_INPUT 203

#define rcDLG_TSHOW 210
#define rcEDT_TSHOW 211
#define ccOUT_TIMER 212
