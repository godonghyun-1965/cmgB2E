@echo off
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
SET cmgCPP=Echo
SET cmgEXE=%cmgCPP%
SET myBCPP=%commander_path%\Bin\MakeTool\BCPP
SET RCsets=-I"%myBCPP%\Include" -r
SET BCsets=-I"%myBCPP%\include" -L"%myBCPP%\lib" -e"%cmgEXE%.exe" -tW -c -O2 -D -v
SET BLsets=-L"%myBCPP%\lib" -aa c0w32
::                              c0w32 �������α׷�
::                              c0x32 �ܼ����α׷�
::                              c0d32 �������α׷�(����׿�)
SET BLdefs=
SET SPsets=-g -S -d -s -x -X
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:Begin
date /T > %cmgEXE%.log

if exist %cmgCPP%.rc %myBCPP%\bin\brc32.exe %RCsets% %cmgCPP%.rc >> %cmgEXE%.log
if errorlevel 1 goto ErrResource

%myBCPP%\bin\bcc32.exe %BCsets% %cmgCPP%.cpp %BLdefs% >> %cmgEXE%.log
if errorlevel 1 goto ErrSource

if exist %cmgCPP%.rc %myBCPP%\bin\ilink32.exe %BLsets% %cmgCPP%.obj,%cmgCPP%, ,import32 cw32, ,%cmgCPP%.res >> %cmgEXE%.log
if not exist %cmgCPP%.rc %myBCPP%\bin\ilink32.exe %BLsets% %cmgCPP%.obj,%cmgCPP%, ,import32 cw32, , >> %cmgEXE%.log
if errorlevel 1 goto ErrLinker

if EXIST %cmgCPP%.obj DEL %cmgCPP%.obj >> %cmgEXE%.log
if EXIST %cmgCPP%.tds DEL %cmgCPP%.tds >> %cmgEXE%.log
if EXIST %cmgCPP%.il? DEL %cmgCPP%.il? >> %cmgEXE%.log
if EXIST %cmgCPP%.RES DEL %cmgCPP%.RES >> %cmgEXE%.log
if EXIST %cmgCPP%.MAP DEL %cmgCPP%.MAP >> %cmgEXE%.log
GOTO OKmess

:ErrResource
echo.  >> %cmgEXE%.log
echo Abnormal Terminate the Compiler for Resource File  >> %cmgEXE%.log
goto Fine

:ErrSource
echo.  >> %cmgEXE%.log
echo Abnormal Terminate the Compiler for Source File  >> %cmgEXE%.log
goto Fine

:ErrLinker
echo.  >> %cmgEXE%.log
echo Abnormal Terminate the Linker  >> %cmgEXE%.log
goto Fine

:OKmess
if not "%SPsets%"=="" %myBCPP%\bin\strip.exe %SPsets% %cmgEXE%.exe >> %cmgEXE%.log
echo Terminate Compile and Link Sucessfully! >> %cmgEXE%.log

:Fine
%commander_path%\bin\cmgEdit.exe %cmgEXE%.log