#define Pversion "01.25.01.11"
#define dlgCaption "cmgB2E "Pversion
#define Fversion 1,25,1,11