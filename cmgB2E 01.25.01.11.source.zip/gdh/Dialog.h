#ifndef DH_DIALOG_COMPACT
#define DH_DIALOG_COMPACT
#include "Strings.h"

int CheckPoint(LPCSTR head, LPCSTR format, ...){
    char buffer[DH_MAX_TEXT];
    va_list argptr;
    va_start(argptr, format);
    vsprintf(buffer, format, argptr);
    va_end(argptr);
    return MessageBox(NULL, buffer, head, MB_OK);
    };

#endif
